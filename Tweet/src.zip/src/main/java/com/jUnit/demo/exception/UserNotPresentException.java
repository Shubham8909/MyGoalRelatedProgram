package com.jUnit.demo.exception;

public class UserNotPresentException extends RuntimeException {

}
