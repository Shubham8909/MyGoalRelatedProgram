package com.jUnit.demo.exception;

public class UserAlreadyPresentException extends RuntimeException{

}
