package com.cleartrip.properties.model;

public enum Status {
	
	AVAILABLE,SOLD

}
