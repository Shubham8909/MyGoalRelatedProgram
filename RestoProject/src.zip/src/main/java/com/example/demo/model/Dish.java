package com.example.demo.model;

public class Dish {
	
	private int dishId ;
	private String name;
	private String description;
	private String image;
	private Type type;
	private Cuisine   Cuisines;
	private double price;

}
