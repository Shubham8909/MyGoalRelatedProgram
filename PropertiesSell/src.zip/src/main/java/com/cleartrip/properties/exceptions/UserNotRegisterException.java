package com.cleartrip.properties.exceptions;

public class UserNotRegisterException extends RuntimeException {
	
private static final long serialVersionUID = 664861615793261621L;
   
	
	public UserNotRegisterException(String msg) {
		super(msg);
	}

}
