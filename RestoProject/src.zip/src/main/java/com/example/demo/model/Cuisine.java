package com.example.demo.model;

public enum Cuisine {
	
	INDIAN,CHINESE,ORIENTAL,CONTINENTAL;

}
