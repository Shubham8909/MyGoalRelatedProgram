import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.demo.model.Restaurants;

@Service
public class RestService {
	
	static Map<String , List<Restaurants>> restmap = new HashMap<String, List<Restaurants>>();

	
	
	

}
